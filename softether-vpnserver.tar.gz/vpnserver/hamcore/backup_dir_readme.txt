======================================================================

                          About Backup Folder

======================================================================

Here are auto backups of configuration files.

You can delete there files to make free space on the disk drive.

