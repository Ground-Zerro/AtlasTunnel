export {};
//# sourceMappingURL=vpnadmin.d.ts.map